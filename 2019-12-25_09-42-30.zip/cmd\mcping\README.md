# mcping
适用于Minecraft: Java Edition的ping工具

Install with go tools:  
    ```go get -u github.com/Tnze/go-mc/cmd/mcping```
    `$GOPATH/bin` should in your `$PATH`.

Install with Homebrew:  
    ```brew tap Tnze/tap && brew install mcping```

Useage:  
    ```mcping <hostname>[:port]```

# NBT
This package implement the Named Binary Tag format of Minecraft.
# Docs
[![GoDoc](https://godoc.org/github.com/Tnze/go-mc/nbt?status.svg)](https://godoc.org/github.com/Tnze/go-mc/nbt)
package world

// import "testing"

// func TestBlockString(t *testing.T) {
// 	for i := uint(0); i < 8598+1; i++ {
// 		t.Log(Block{id: i})
// 	}
// }
